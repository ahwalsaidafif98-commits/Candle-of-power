package com.candleofpower;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.ItemEvents;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.Map;

public class CandleOfPower implements ModInitializer {
    private static final int DURATION_TICKS = 20 * 30; // 30 detik
    private static final int COOLDOWN_TICKS = 20 * 60; // 60 detik

    private record Power(Holder<MobEffect> effect, int amplifier, String name) {}

    private static final Map<Item, Power> POWERS = Map.ofEntries(
        Map.entry(Items.WHITE_CANDLE,       new Power(MobEffects.RESISTANCE, 1, "Perlindungan")),
        Map.entry(Items.ORANGE_CANDLE,      new Power(MobEffects.FIRE_RESISTANCE, 0, "Api")),
        Map.entry(Items.MAGENTA_CANDLE,     new Power(MobEffects.LUCK, 1, "Keberuntungan")),
        Map.entry(Items.LIGHT_BLUE_CANDLE,  new Power(MobEffects.SLOW_FALLING, 0, "Angin")),
        Map.entry(Items.YELLOW_CANDLE,      new Power(MobEffects.HASTE, 1, "Penambangan")),
        Map.entry(Items.LIME_CANDLE,        new Power(MobEffects.JUMP_BOOST, 2, "Lompatan")),
        Map.entry(Items.PINK_CANDLE,        new Power(MobEffects.ABSORPTION, 2, "Perisai")),
        Map.entry(Items.GRAY_CANDLE,        new Power(MobEffects.INVISIBILITY, 0, "Bayangan")),
        Map.entry(Items.LIGHT_GRAY_CANDLE,  new Power(MobEffects.NIGHT_VISION, 0, "Penglihatan")),
        Map.entry(Items.CYAN_CANDLE,        new Power(MobEffects.WATER_BREATHING, 0, "Laut")),
        Map.entry(Items.PURPLE_CANDLE,      new Power(MobEffects.LEVITATION, 0, "Gravitasi")),
        Map.entry(Items.BLUE_CANDLE,        new Power(MobEffects.DOLPHINS_GRACE, 1, "Arus")),
        Map.entry(Items.BROWN_CANDLE,       new Power(MobEffects.HEALTH_BOOST, 1, "Vitalitas")),
        Map.entry(Items.GREEN_CANDLE,       new Power(MobEffects.REGENERATION, 1, "Pemulihan")),
        Map.entry(Items.RED_CANDLE,         new Power(MobEffects.STRENGTH, 2, "Kekuatan")),
        Map.entry(Items.BLACK_CANDLE,       new Power(MobEffects.SPEED, 2, "Energi Gelap"))
    );

    @Override
    public void onInitialize() {
        // Klik kanan di udara: aktifkan kemampuan, bukan meletakkan lilin.
        ItemEvents.USE.register((Level level, Player player, net.minecraft.world.InteractionHand hand) -> {
            Item item = player.getItemInHand(hand).getItem();
            Power power = POWERS.get(item);
            if (power == null) return null;
            activate(level, player, item, power);
            return InteractionResult.SUCCESS;
        });

        // Klik kanan pada blok: cegah lilin diletakkan dan aktifkan kemampuan.
        ItemEvents.USE_ON.register(context -> {
            Item item = context.getItemInHand().getItem();
            Power power = POWERS.get(item);
            if (power == null) return null;
            activate(context.getLevel(), context.getPlayer(), item, power);
            return InteractionResult.SUCCESS;
        });
    }

    private static void activate(Level level, Player player, Item item, Power power) {
        if (level.isClientSide() || player == null) return;
        if (player.getCooldowns().isOnCooldown(item)) return;

        player.addEffect(new MobEffectInstance(power.effect(), DURATION_TICKS, power.amplifier()));
        player.getCooldowns().addCooldown(item, COOLDOWN_TICKS);
        player.displayClientMessage(
            Component.literal("Candle of Power: " + power.name() + " aktif selama 30 detik!"),
            true
        );
    }
}
