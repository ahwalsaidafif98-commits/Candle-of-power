CANDLE OF POWER — SOURCE PROJECT
Minecraft Java 26.2 | Fabric | Java 25

FITUR PROTOTIPE
- Memakai 16 item lilin bawaan Minecraft.
- Klik kanan di udara mengaktifkan kemampuan.
- Klik kanan pada blok juga mengaktifkan kemampuan, bukan meletakkan lilin.
- Lilin tidak dikonsumsi.
- Efek hanya diterapkan ke pemain yang mengaktifkannya.
- Durasi efek: 30 detik.
- Cooldown tiap warna lilin: 60 detik.

KEMAMPUAN
Putih: Resistance II
Oranye: Fire Resistance
Magenta: Luck II
Biru muda: Slow Falling
Kuning: Haste II
Lime: Jump Boost III
Pink: Absorption III
Abu-abu: Invisibility
Abu-abu muda: Night Vision
Cyan: Water Breathing
Ungu: Levitation
Biru: Dolphin's Grace II
Cokelat: Health Boost II
Hijau: Regeneration II
Merah: Strength III
Hitam: Speed III

CATATAN PENTING
Ini adalah SOURCE PROJECT, belum file .jar terkompilasi dan belum diuji
dengan menjalankan Minecraft. API Fabric 26.2 dan nama-nama effect perlu
diverifikasi melalui proses build. Jika Gradle melaporkan simbol MobEffects
yang tidak dikenal, sesuaikan nama field dengan mapping 26.2 yang dipakai.

BUILD
Persyaratan:
- JDK 25
- Gradle 9.5.1 atau yang kompatibel dengan Fabric Loom 1.17
- Koneksi internet saat Gradle mengunduh dependensi

Dari folder proyek jalankan:
    gradle build

Hasil JAR biasanya ada di:
    build/libs/Candle-of-Power-1.0.0.jar

Pasang JAR ke folder .minecraft/mods bersama Fabric API 26.2.
Untuk Zalith Launcher 2, gunakan folder mods pada instance Minecraft 26.2.

PERINGATAN
Buat salinan world sebelum menguji mod. Di server multiplayer, kemampuan
status effect umumnya diproses oleh server; server harus mengizinkan mod ini
agar efek bekerja dengan benar.
